PATCH_LIB("libanogs.so","0x1D78CC","00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so","0x4D47D8","00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so","0x228068","00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so","0x228360","00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so","0x1D7938","00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so","0x1D5A88","00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libUE4.so", "0x6c2d3c8", "00 00 80 D2 C0 03 5F D6");//RecordShootVerifyStatType
PATCH_LIB("libUE4.so", "0x6f59c64", "00 00 80 D2 C0 03 5F D6");//BulletTrackComponent
PATCH_LIB("libUE4.so", "0x6e46a3c", "00 00 80 D2 C0 03 5F D6");//RPC_Client_ShootVertifyRes
PATCH_LIB("libUE4.so", "0x6e49d4c", "00 00 80 D2 C0 03 5F D6");//ServerHandleBulletHitData
PATCH_LIB("libUE4.so", "0x6f9f098", "00 00 80 D2 C0 03 5F D6");//ShootCharacterVertify
PATCH_LIB("libUE4.so", "0x6f5c4c8", "00 00 80 D2 C0 03 5F D6");//HandleSingleRelpayHitData
PATCH_LIB("libUE4.so", "0x7ab1c68", "00 00 80 D2 C0 03 5F D6");//Func23 HitResult
PATCH_LIB("libUE4.so", "0x7ab2228", "00 00 80 D2 C0 03 5F D6");//Func28